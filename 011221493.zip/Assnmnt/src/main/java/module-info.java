module com.example.assnmnt {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.example.assnmnt to javafx.fxml;
    exports com.example.assnmnt;
}