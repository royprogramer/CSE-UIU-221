package com.example.assnmnt;

import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.IOException;

public class NextScreenwriterController {
    public void goBack(ActionEvent event) throws IOException {
        Parent root3 = FXMLLoader.load(getClass().getResource("Calculator-view.fxml"));
        Scene scene3 = new Scene(root3);

        Stage stage3 = (Stage) ((Node)event.getSource()).getScene().getWindow();

        stage3.setScene(scene3);
        stage3.show();


    }

}
