package com.example.assnmnt;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.io.IOException;

public class CalculatorController{
    @FXML
    private Label convertedValue;

    @FXML
    private TextField decimalValue;
    int input;
    String s;

    public void validation() {
        s = decimalValue.getText();
        if(s.contains(".")){
            try {
                input = Integer.parseInt(decimalValue.getText());
            }
            catch (NumberFormatException e){
                System.out.println(e);
                convertedValue.setText("No Input Given");
            }
        }
        else {
            try {
                input = Integer.parseInt(decimalValue.getText());
            }
            catch (NumberFormatException e){
                System.out.println(e);
                convertedValue.setText("Not a Number!");
            }
        }
    }

    @FXML
    void b(ActionEvent event) {
        validation();
        try {
            convertedValue.setText(Integer.toBinaryString(Integer.parseInt(decimalValue.getText())));
        }
        catch (Exception e){
            System.out.println(e);
        }
    }
    @FXML
    void h(ActionEvent event) {
        validation();
        try {
            convertedValue.setText(Integer.toHexString(Integer.parseInt(decimalValue.getText())));
        }
        catch (Exception e)
        {
            System.out.println(e);
        }
    }
    @FXML
    void o(ActionEvent event){
        validation();
        try{
            convertedValue.setText(Integer.toOctalString(Integer.parseInt(decimalValue.getText())));
        }
        catch (Exception e){
            System.out.println(e);
        }
    }

    @FXML
    void clear(ActionEvent event) {
       convertedValue.setText("No Input");
       decimalValue.setText("Place a Decimal Input Here");

    }

    @FXML
    void exit(ActionEvent event) {
        Stage stage4 = (Stage) ((Node)event.getSource()).getScene().getWindow();
        stage4.close();
    }

    @FXML
    public void nextScreen(ActionEvent event) throws IOException {
        Parent root2 = FXMLLoader.load(getClass().getResource("NextScreen-view.fxml"));
        Scene scene2 = new Scene(root2);

        Stage stage2 = (Stage) ((Node)event.getSource()).getScene().getWindow();

        stage2.setScene(scene2);
        stage2.show();


    }

}